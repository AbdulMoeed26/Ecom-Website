<?php
session_start();

$_SESSION['count'] = 0;



$name = $_POST['prodname'];
$price = $_POST['prodprice'];
$qty = $_POST['prodqty'];

$product = array($name, $price, $qty);



$_SESSION['name'] = $name;
$_SESSION['price'] = $price;
$_SESSION['qty'] = $qty;

header('Location: ' . $_SERVER['HTTP_REFERER']);

?>