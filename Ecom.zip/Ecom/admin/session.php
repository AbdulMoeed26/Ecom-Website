<?php
session_start();

if ( !$_SESSION[ 'loggeduser' ] ) {
    header( 'Location: ../auth.php?fail="unauth"' );
}
$custemail = $_SESSION[ 'loggeduser' ];

include( '../config.php' );
$db = new Dbconnection();
$con = $db->getConnection();

$query='select * from customer where custemail = ?';
$stmt= $con->prepare($query);
$stmt->bindParam( 1, $custemail );
$stmt->execute();
$result = $stmt->fetch();



if ( isset( $_POST[ 'logout' ] ) ) {
    session_unset();
    session_destroy();
    header( 'Location: ../auth.php' );
}

?>