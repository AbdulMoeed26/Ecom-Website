<?php

include('../config.php');



$db = new DBConnection();
$con = $db->getConnection();
$id = $_GET['id'];

$customer = $con->prepare("delete from product where pid = ?");
$customer->bindParam(1, $id);
$customer->execute();
header("Location: ./showproducts.php");

?>
