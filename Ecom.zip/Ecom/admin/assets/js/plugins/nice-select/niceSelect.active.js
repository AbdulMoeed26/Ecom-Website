(function ($) {
    "use strict";
    
    /*Nice Select*/
    if( $('.nice-select').length ) {
        $('.nice-select').niceSelect();
    }
    
})(jQuery);