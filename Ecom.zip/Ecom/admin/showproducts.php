<?php
include('./session.php');
include('./header.php');

$query = $con->prepare("select * from product");
$query->execute();

$records = $query->fetchAll(PDO::FETCH_OBJ);



?>

<!-- Content Body Start -->
<div class = 'content-body'>

<!-- Page Headings Start -->
<div class = 'row justify-content-between align-items-center mb-10'>

<!-- Page Heading Start -->
<div class = 'col-12 col-lg-auto mb-20'>
<div class = 'page-heading'>
<h3>eCommerce <span>/ Show Product</span></h3>
</div>
</div><!-- Page Heading End -->

</div><!-- Page Headings End -->

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">PId</th>
                            <th scope="col">PName</th>
                            <th scope="col">Pcatid</th>
                            <th scope="col">Pshortdesc</th>
                            <th scope="col">plongdesc</th>
                            <th scope="col">Thumbnail</th>
                            <th scope="col">Pimageid</th>
                            <th scope="col">Pprice</th>
                            <th scope="col">Pstock</th>
                            <th scope="col">Pisfeatured</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($records as $row) { ?>
                            <tr>
                                <th scope="row"><?php echo $row->pid; ?></th>
                                <td><?php echo $row->pname; ?></td>
                                <td><?php echo $row->pcatid; ?></td>
                                <td><?php echo $row->pshortdesc; ?></td>
                                <td><?php echo $row->plongdesc; ?></td>
                                <td>
                                    
                                    <img src='<?php echo "../upload/$row->pthumb"  ?>' alt="" width="80px" height="80px" >
                                </td>
                                <td><?php echo $row->pimageid; ?></td>
                                <td><?php echo $row->pprice; ?></td>
                                <td><?php echo $row->pstock; ?></td>
                                <td><?php echo $row->pisfeatured; ?></td>
                                    <td>
                                        
                                        <a href="./edit-product.php?id=<?php echo $row->pid ?>"><i class="fas fa-edit"></i></a>
                                        <a href="./delete-product.php?id=<?php echo $row->pid ?>"><i class="fa-solid fa-trash"></i></a>
                                
                                    </td>
                            </tr>
                        <?php }
                        ?>
                    </tbody>
                </table>
          

</div><!-- Content Body End -->

<?php
include('./footer.php');
?>