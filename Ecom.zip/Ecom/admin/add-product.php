<?php


include('./session.php');
include('./header.php');

$query2 = 'select * from category';
$stmt2 = $con->prepare( $query2 );
$stmt2->execute();
$result2 = $stmt2->fetchAll(PDO::FETCH_OBJ);

if ( isset( $_POST[ 'save' ] ) ) {


$filename = $_FILES['myimage']['name'];
$file_tmpname = $_FILES['myimage']['tmp_name'];

$pthumb = $_FILES['pthumb']['name'];
$pthumb_tmp = $_FILES['pthumb']['tmp_name'];

move_uploaded_file($file_tmpname, "../upload/$filename");
move_uploaded_file($pthumb_tmp, "../upload/$pthumb");


$query4 = "insert into productimage(imagename) values(?)";
$stm4 = $con->prepare($query4);
$stm4->bindparam(1, $filename);
$stm4->execute();



    $pname = $_POST[ 'pname' ];
    $pcatid = $_POST[ 'pcatid' ];
    $pshortdesc = $_POST[ 'pshortdesc' ];
    $plongdesc = $_POST[ 'plongdesc' ];
    
    $id = $con->lastInsertId();
    $pprice = $_POST[ 'pprice' ];
    $pstock = $_POST[ 'pstock' ];
    $pisfeatured = $_POST[ 'pisfeatured' ];

    $query1 = $con->prepare( 'insert into product (pname,pcatid,pshortdesc,plongdesc,pthumb,pimageid,pprice,pstock,pisfeatured) values(?, ?, ?, ?, ?, ?, ?, ?, ?)' );

    $query1->bindparam( 1, $pname );
    $query1->bindparam( 2, $pcatid );
    $query1->bindparam( 3, $pshortdesc );
    $query1->bindparam( 4, $plongdesc );
    $query1->bindparam( 5, $pthumb );
    $query1->bindParam( 6 ,$id);
    $query1->bindparam( 7, $pprice );
    $query1->bindparam( 8, $pstock );
    $query1->bindparam( 9, $pisfeatured );
    $query1->execute();

}



?>


<!-- Content Body Start -->
<div class = 'content-body'>

<!-- Page Headings Start -->
<div class = 'row justify-content-between align-items-center mb-10'>

<!-- Page Heading Start -->
<div class = 'col-12 col-lg-auto mb-20'>
<div class = 'page-heading'>
<h3>eCommerce <span>/ Add Product</span></h3>
</div>
</div><!-- Page Heading End -->

<!-- Add or Edit Product Start -->
<form action = '' method = 'POST' enctype="multipart/form-data">
<div class = 'add-edit-product-wrap col-12'>

<div class = 'add-edit-product-form'>
<form action = '' method = 'POST' enctype="multipart/form-data">

<h4 class = 'title'>About Product</h4>

<div class = 'row'>
<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'text' placeholder = 'Product Name / Title*' name = 'pname'></div>
<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'text' placeholder = 'Product short desc' name = 'pshortdesc'></div>
<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'text' placeholder = 'Product Price*' name = 'pprice'></div>
<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'text' placeholder = 'Product stock*' name = 'pstock'></div>
<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'text' placeholder = 'Product isfeatured' name = 'pisfeatured'></div>
<div class = 'col-lg-6 col-12 mb-30'><input class = 'form-control' type = 'file' placeholder = 'Product thumbnail' name = 'pthumb'></div>
<div class = 'col-12 mb-30'><textarea class = 'form-control' placeholder = 'Product long Description*' name = 'plongdesc'></textarea></div>
<div class = 'col-12 mb-30'>

<div class="input-group mb-3">
  <div class="input-group-prepend">
    <button class="btn btn-outline-secondary" type="button">Categories</button>
  </div>
  <select class="custom-select" id="inputGroupSelect03" name = 'pcatid' >
  <?php
foreach($result2 as $row)
{ ?>
    <option value="<?php echo $row->catid; ?>"><?php echo $row->catname; ?></option>
<?php  }
?>
    
  </select>
</div>


</div>
</div>

<h4 class = 'title'>Product Gallery</h4>

<div class = 'product-upload-gallery row flex-wrap'>
<div class = 'col-12 mb-30'>
<p class = 'form-help-text mt-0'>Upload Maximum 800 x 800 px & Max size 2mb.</p>
<div class="input-group input-group-sm mb-3">
  <input type = 'file'  name="myimage" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
</div>
</div>
</div>


<!-- Button Group Start -->
<div class = 'row'>
<div class = 'd-flex flex-wrap justify-content-end col mbn-10'>
<button type="submit" class = 'btn btn-outline-secondary mb-10 ml-10 mr-0' name = 'save'>Save</button>
<button class = 'btn btn-outline-secondary mb-10 ml-10 mr-0'><a href="showproducts.php"> Show Products</a></button>

</div>
</div><!-- Button Group End -->

</form>
</div>

</div><!-- Add or Edit Product End -->

</form>

</div><!-- Content Body End -->

<?php
  include('./footer.php');
?>