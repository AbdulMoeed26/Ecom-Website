<?php
include('./template/header.php');

include('./config.php');
$db = new DBConnection;
$con = $db->getConnection();
$query = " SELECT * FROM product ";
$stmt = $con->prepare($query);
$stmt->execute();
$record = $stmt->fetchAll(PDO::FETCH_OBJ);

$query1 = " SELECT * FROM `product` WHERE pcatid = 1 ";
$stmt1 = $con->prepare($query1);
$stmt1->execute();
$record1 = $stmt1->fetchAll(PDO::FETCH_OBJ); 


$query2 = " SELECT * FROM `product` WHERE pcatid = 2 ";
$stmt2 = $con->prepare($query2);
$stmt2->execute();
$record2 = $stmt2->fetchAll(PDO::FETCH_OBJ); 

$query3 = " SELECT * FROM `product` WHERE pcatid = 3 ";
$stmt3 = $con->prepare($query3);
$stmt3->execute();
$record3 = $stmt3->fetchAll(PDO::FETCH_OBJ);


$query4 = " SELECT * FROM `product` WHERE pcatid = 4 ";
$stmt4 = $con->prepare($query4);
$stmt4->execute();
$record4 = $stmt4->fetchAll(PDO::FETCH_OBJ);

$query5 = " SELECT * FROM `product` WHERE pcatid = 5 ";
$stmt5 = $con->prepare($query5);
$stmt5->execute();
$record5 = $stmt5->fetchAll(PDO::FETCH_OBJ);

?>




<!-- Main Content - start -->
<main>
    <section class="container">


        <!-- Slider -->
        <div class="fr-slider-wrap">
            <div class="fr-slider">
                <ul class="slides">
                    <li>
                        <img  src="img/slider/ss.jpg" height="" width="1200px" alt="">
                        <div class="fr-slider-cont">
                            <h3>MEGA SALE -30%</h3>
                            
                            <p class="fr-slider-more-wrap">
                                <a class="fr-slider-more" href="">View Items collection</a>
                            </p>
                        </div>
                    </li>
                    <li>
                    <img src="img/slider/s1.jpg" height="1200px" width="1200px" alt="">
                        <div class="fr-slider-cont">
                            <h3>NEW COLLECTION</h3>
                            <p class="fr-slider-more-wrap">
                                <a class="fr-slider-more" href="#">Shopping now</a>
                            </p>
                        </div>
                    </li>
                    <li>
                    <img src="img/slider/s3.jpg" height="1200px" width="1200px" alt="">
                        <div class="fr-slider-cont">

                                <a class="fr-slider-more" href="#">Start shopping</a>
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>


        <!-- Popular Products -->
        <div class="fr-pop-wrap">

            <h3 class="component-ttl"><span>Popular products</span></h3>

            <ul class="fr-pop-tabs sections-show">
                <li><a data-frpoptab-num="1" data-frpoptab="#frpoptab-tab-1" href="#" class="active">All Categories</a></li>
                <li><a data-frpoptab-num="2" data-frpoptab="#frpoptab-tab-2" href="#">Electronics</a></li>
                <li><a data-frpoptab-num="3" data-frpoptab="#frpoptab-tab-3" href="#">Mobile Phones</a></li>
                <li><a data-frpoptab-num="4" data-frpoptab="#frpoptab-tab-4" href="#">Furniture</a></li>
                <li><a data-frpoptab-num="5" data-frpoptab="#frpoptab-tab-5" href="#">Kitchen accessories</a></li>
                <li><a data-frpoptab-num="5" data-frpoptab="#frpoptab-tab-6" href="#">Jewellery</a></li>
            </ul>

            <div class="fr-pop-tab-cont">

                <p data-frpoptab-num="1" class="fr-pop-tab-mob active" data-frpoptab="#frpoptab-tab-1">All Categories</p>
                <div class="flexslider prod-items fr-pop-tab" id="frpoptab-tab-1">

                <ul class="slides">

                    <?php

                    foreach($record as $row)
                    { ?>
                        <li class="prod-i">
                        <div class="prod-i-top">
                            <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt=""><!-- NO SPACE --></a>
                            <p class="prod-i-info">
                                <a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
                                <a href="#" class="qview-btn prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
                                <a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
                            </p>
                            <p class="prod-i-addwrap">
                                <a href='product.php?id=<?php echo $row->pid; ?> ' class="prod-i-add">Go to detail</a>
                            </p>
                        </div>
                        
                        <h3>
                            <a href="product.php"><?php echo $row->pname; ?></a>
                        </h3>
                        <p class="prod-i-price">
                            <b><?php echo $row->pprice."RS"; ?></b>
                        </p>
                        <div class="prod-i-skuwrapcolor">
                            <ul class="prod-i-skucolor">
                                <li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
                                <li><img src="img/color/blue.jpg" alt="Blue"></li>
                            </ul>
                        </div>
                    </li>
                    <?php }
?>
                </ul>
                </div>

                


                <p data-frpoptab-num="2" class="fr-pop-tab-mob" data-frpoptab="#frpoptab-tab-2">Electronics</p>
                <div class="flexslider prod-items fr-pop-tab" id="frpoptab-tab-2">
                <?php

//ELECTRONICS
foreach($record1 as $row)
{ ?>

                    <ul class="slides">

                        <li class="prod-i">
                            <div class="prod-i-top">
                                <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
                                <p class="prod-i-info">
                                    <a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
                                    <a href="#" class="prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
                                    <a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
                                </p>
                                <p class="prod-i-addwrap">
                                    <a href="#" class="prod-i-add">Go to detail</a>
                                </p>
                            </div>
                            <a href="product.php"><?php echo $row->pname; ?></a>
                        </h3>
                        <p class="prod-i-price">
                            <b><?php echo $row->pprice."RS"; ?></b>
                        </p>
                        <div class="prod-i-skuwrapcolor">
                            <ul class="prod-i-skucolor">
                                <li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
                                <li><img src="img/color/blue.jpg" alt="Blue"></li>
                            </ul>
                        </div>
                    </li>
                    <?php }
?>
                        </li>

                    </ul>
                </div>
                <!-- MOBILE PHONES -->
                <p data-frpoptab-num="3" class="fr-pop-tab-mob" data-frpoptab="#frpoptab-tab-3">Mobile Phones</p>
                <div class="flexslider prod-items fr-pop-tab" id="frpoptab-tab-3">

                    <ul class="slides">

                    <?php

foreach($record2 as $row)
{ ?>
    <li class="prod-i">
    <div class="prod-i-top">
        <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
        <p class="prod-i-info">
            <a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
            <a href="#" class="qview-btn prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
            <a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
        </p>
        <p class="prod-i-addwrap">
            <a href="#" class="prod-i-add">Go to detail</a>
        </p>
    </div>
    <h3>
        <a href="product.php"><?php echo $row->pname; ?></a>
    </h3>
    <p class="prod-i-price">
        <b><?php echo $row->pprice."RS"; ?></b>
    </p>
    <div class="prod-i-skuwrapcolor">
        <ul class="prod-i-skucolor">
            <li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
            <li><img src="img/color/blue.jpg" alt="Blue"></li>
        </ul>
    </div>
</li>
<?php }
?>
</li>


                    </ul>
                </div>

<!-- Furniture -->

                <p data-frpoptab-num="4" class="fr-pop-tab-mob" data-frpoptab="#frpoptab-tab-4">Men</p>
                <div class="flexslider prod-items fr-pop-tab" id="frpoptab-tab-4">

                    <ul class="slides">
    <?php
                    foreach($record3 as $row)
{ ?>
    <li class="prod-i">
    <div class="prod-i-top">
        <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
        <p class="prod-i-info">
            <a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
            <a href="#" class="qview-btn prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
            <a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
        </p>
        <p class="prod-i-addwrap">
            <a href="#" class="prod-i-add">Go to detail</a>
        </p>
    </div>
    <h3>
        <a href="product.php"><?php echo $row->pname; ?></a>
    </h3>
    <p class="prod-i-price">
        <b><?php echo $row->pprice."RS"; ?></b>
    </p>
    <div class="prod-i-skuwrapcolor">
        <ul class="prod-i-skucolor">
            <li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
            <li><img src="img/color/blue.jpg" alt="Blue"></li>
        </ul>
    </div>
</li>
<?php }
?>
</li>

                    </ul>

                </div>


                <p data-frpoptab-num="5" class="fr-pop-tab-mob" data-frpoptab="#frpoptab-tab-5">Kitchen Accessories</p>
                <div class="flexslider prod-items fr-pop-tab" id="frpoptab-tab-5">

                    <ul class="slides">
                    <?php

foreach($record4 as $row)
{ ?>
    <li class="prod-i">
    <div class="prod-i-top">
        <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
        <p class="prod-i-info">
            <a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
            <a href="#" class="qview-btn prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
            <a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
        </p>
        <p class="prod-i-addwrap">
            <a href="#" class="prod-i-add">Go to detail</a>
        </p>
    </div>
    <h3>
        <a href="product.php"><?php echo $row->pname; ?></a>
    </h3>
    <p class="prod-i-price">
        <b><?php echo $row->pprice."RS"; ?></b>
    </p>
    <div class="prod-i-skuwrapcolor">
        <ul class="prod-i-skucolor">
            <li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
            <li><img src="img/color/blue.jpg" alt="Blue"></li>
        </ul>
    </div>
</li>
<?php }
?>
</li>



                    </ul>

                </div>

                <p data-frpoptab-num="6" class="fr-pop-tab-mob" data-frpoptab="#frpoptab-tab-6">Jewellery</p>
                <div class="flexslider prod-items fr-pop-tab" id="frpoptab-tab-6">

                    <ul class="slides">
                    <?php

foreach($record5 as $row)
{ ?>
    <li class="prod-i">
    <div class="prod-i-top">
        <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
        <p class="prod-i-info">
            <a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
            <a href="#" class="qview-btn prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
            <a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
        </p>
        <p class="prod-i-addwrap">
            <a href="#" class="prod-i-add">Go to detail</a>
        </p>
    </div>
    <h3>
        <a href="product.php"><?php echo $row->pname; ?></a>
    </h3>
    <p class="prod-i-price">
        <b><?php echo $row->pprice."RS"; ?></b>
    </p>
    <div class="prod-i-skuwrapcolor">
        <ul class="prod-i-skucolor">
            <li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
            <li><img src="img/color/blue.jpg" alt="Blue"></li>
        </ul>
    </div>
</li>
<?php }
?>
</li>



                    </ul>

                </div>


            </div><!-- .fr-pop-tab-cont -->


        </div><!-- .fr-pop-wrap -->


        <!-- Banners -->
        <div class="banners-wrap">
            <div class="banners-list">
                <div class="banner-i style_11">
                    <span class="banner-i-bg" style="background: url(img/slider/mobile.jpg); width:560px; height:360px;"></span>
                    <div class="banner-i-cont">
                        <p class="banner-i-subttl">NEW COLLECTION</p>
                        <h3 class="banner-i-ttl">MOBILE<br>PHONES'S</h3>
                        <p class="banner-i-link"><a href="section.php">View More</a></p>
                    </div>
                </div>
                <div class="banner-i style_22">
                    <span class="banner-i-bg" style="background: url(img/slider/kitchens.jpg); width:270px; height:360px;"></span>
                    <div class="banner-i-cont">
                        <p class="banner-i-subttl">GREAT COLLECTION</p>
                        <h3 class="banner-i-ttl">KITCHEN<br>ACCESSORIES</h3>
                        <p class="banner-i-link"><a href="section.php">Show more</a></p>
                    </div>
                </div>
                <div class="banner-i style_21">
                    <span class="banner-i-bg" style="background: url(img/slider/electronics.jpg); width:270px; height:360px;"></span>
                    <div class="banner-i-cont">
                        <h3 class="banner-i-ttl">ELETRONICS</h3>
                        <p class="banner-i-link"><a href="section.php">Go to catalog</a></p>
                    </div>
                </div>
                <div class="banner-i style_21">
                    <span class="banner-i-bg" style="background: url(img/slider/fur.jpg); width:270px; height:360px;"></span>
                    <div class="banner-i-cont">
                        <h3 class="banner-i-ttl">FURNITURE</h3>
                        <p class="banner-i-link"><a href="section.php">View More</a></p>
                    </div>
                </div>
                <div class="banner-i style_22">
                    <span class="banner-i-bg" style="background: url(img/slider/jewllery.jpg); width:270px; height:360px;"></span>
                    <div class="banner-i-cont">
                        <p class="banner-i-subttl">DISCOUNT -20%</p>
                        <h3 class="banner-i-ttl">JEWELLERY<br>COLLECTION</h3>
                        <p class="banner-i-link"><a href="section.php">Shop now</a></p>
                    </div>
                </div>
                <div class="banner-i style_12">
                    <span class="banner-i-bg" style="background: url(img/slider/laptop.jpg); width:560px; height:360px;"></span>
                    <div class="banner-i-cont">
                        <h3 class="banner-i-ttl">LAPTOPS</h3>

                        <p class="banner-i-link"><a href="section.php">View More</a></p>
                    </div>
                </div>
            </div>
        </div>


        <!-- Special offer -->
        <div class="discounts-wrap">
            <h3 class="component-ttl"><span>Special offer</span></h3>
            <div class="flexslider discounts-list">
                <ul class="slides">
                <?php

foreach($record as $row)
{ ?>
    <li class="prod-i">
    <div class="prod-i-top">
        <a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
     
    </div>
    
    <h3>
        <a href="product.php"><?php echo $row->pname; ?></a>
    </h3>
    <p class="prod-i-price">
        <b><?php echo $row->pprice."RS"; ?></b>
    </p>
</li>
<?php }
?>
                </ul>
            </div>
            <div class="discounts-info">
                <p>Special offer!<br>Limited time only</p>
                <a href="catalog-list.php">Shop now</a>
            </div>
        </div>

        
        <!-- Latest news -->
        <div class="posts-wrap">
            <div class="posts-list">
                <div class="posts-i">
                    <a class="posts-i-img" href="https://kwork.com/user/abdulmoeed">
                        <span style="background: url(./img/slider/review.jpg)";></span>
                    </a>
                    <time class="posts-i-date" datetime="2016-11-09 00:00:00"><span>30</span> Jan</time>
                    <div class="posts-i-info">
                        <a href="blog.php" class="posts-i-ctg">Reviews</a>
                        <h3 class="posts-i-ttl">
                            <a href="https://kwork.com/user/abdulmoeed"></a>
                        </h3>
                    </div>
                </div>
                <div class="posts-i">
                    <a class="posts-i-img" href="https://www.dawn.com/newspaper/column">
                    <span style="background: url(./img/slider/article.jpg)";></span>
                    </a>
                    <time class="posts-i-date" datetime="2016-11-09 00:00:00"><span>29</span> Jan</time>
                    <div class="posts-i-info">
                        <a href="blog.php" class="posts-i-ctg">Articles</a>
                        <h3 class="posts-i-ttl">
                            <a href="https://www.dawn.com/newspaper/column"></a>
                        </h3>
                    </div>
                </div>
                <div class="posts-i">
                    <a class="posts-i-img" href="https://www.dawn.com/">
                        <span style="background: url(./img/slider/news.jpg)"></span>
                    </a>
                    <time class="posts-i-date" datetime="2016-11-09 00:00:00"><span>25</span> Jan</time>
                    <div class="posts-i-info">
                        <a href="blog.php" class="posts-i-ctg">News</a>
                        <h3 class="posts-i-ttl">
                            <a href="https://www.dawn.com/"></a>
                        </h3>
                    </div>
                </div>
            </div>
        </div>

<?php
include('./template/footer.php');
?>



