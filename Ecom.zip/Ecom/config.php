<?php

class DBConnection{
    private $host = 'localhost';
    private $database = 'ecom';
    private $username = 'root';
    private $password = '';

    public function getConnection()
    {
        try{
            $con = new PDO("mysql:host=$this->host;dbname=$this->database", $this->username, $this->password);
            return $con;
        }
        catch(PDOException $e)
        {
            echo $e;
        }
    }
}

?>