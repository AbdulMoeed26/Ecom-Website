<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="format-detection" content="telephone=no">
	<title>AllStore - MultiConcept eCommerce Template</title>

	<link href="https://fonts.googleapis.com/css?family=PT+Serif:400,400i,700,700ii%7CRoboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic" rel="stylesheet">

	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/ion.rangeSlider.css">
	<link rel="stylesheet" href="css/ion.rangeSlider.skinFlat.css">
	<link rel="stylesheet" href="css/jquery.bxslider.css">
	<link rel="stylesheet" href="css/jquery.fancybox.css">
	<link rel="stylesheet" href="css/flexslider.css">
	<link rel="stylesheet" href="css/swiper.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/media.css">

</head>
<body>
<!-- Header - start -->
<header class="header">

	<!-- Topbar - start -->
	<div class="header_top">
		<div class="container">
			<ul class="contactinfo nav nav-pills">
				<li>
					<i class='fa fa-phone'></i> +7 777 123 1575
				</li>
				<li>
					<i class="fa fa-envelope"></i> admin@real-web.pro
				</li>
			</ul>
			<!-- Social links -->
			<ul class="social-icons nav navbar-nav">
				<li>
					<a href="http://facebook.com" rel="nofollow" target="_blank">
						<i class="fa fa-facebook"></i>
					</a>
				</li>
				<li>
					<a href="http://google.com" rel="nofollow" target="_blank">
						<i class="fa fa-google-plus"></i>
					</a>
				</li>
				<li>
					<a href="http://twitter.com" rel="nofollow" target="_blank">
						<i class="fa fa-twitter"></i>
					</a>
				</li>
				<li>
					<a href="http://vk.com" rel="nofollow" target="_blank">
						<i class="fa fa-vk"></i>
					</a>
				</li>
				<li>
					<a href="http://instagram.com" rel="nofollow" target="_blank">
						<i class="fa fa-instagram"></i>
					</a>
				</li>
			</ul>		</div>
	</div>
	<!-- Topbar - end -->

	<!-- Logo, Shop-menu - start -->
	<div class="header-middle">
		<div class="container header-middle-cont">
			<div class="toplogo">
				<a href="index.html">
					<img src="img/logo.png" alt="AllStore - MultiConcept eCommerce Template">
				</a>
			</div>
			<div class="shop-menu">
				<ul>

					<li>
						<a href="wishlist.html">
							<i class="fa fa-heart"></i>
							<span class="shop-menu-ttl">Wishlist</span>
							(<span id="topbar-favorites">1</span>)
						</a>
					</li>

					<li>
						<a href="compare.html">
							<i class="fa fa-bar-chart"></i>
							<span class="shop-menu-ttl">Compare</span> (5)
						</a>
					</li>

					<li class="topauth">
						<a href="auth.html">
							<i class="fa fa-lock"></i>
							<span class="shop-menu-ttl">Registration</span>
						</a>
						<a href="auth.html">
							<span class="shop-menu-ttl">Login</span>
						</a>
					</li>

					<li>
						<div class="h-cart">
							<a href="cart.html">
								<i class="fa fa-shopping-cart"></i>
								<span class="shop-menu-ttl">Cart</span>
								(<b>0</b>)
							</a>
						</div>
					</li>

				</ul>
			</div>
		</div>
	</div>
	<!-- Logo, Shop-menu - end -->

	<!-- Topmenu - start -->
	<div class="header-bottom">
		<div class="container">
			<nav class="topmenu">

				<!-- Catalog menu - start -->
				<div class="topcatalog">
					<a class="topcatalog-btn" href="catalog-list.html"><span>All</span> catalog</a>
					<ul class="topcatalog-list">
						<li>
							<a href="catalog-list.html">
								Women
							</a>
							<i class="fa fa-angle-right"></i>
							<ul>
								<li>
									<a href="catalog-list.html">
										Knitwear
									</a>
								</li>
								<li>
									<a href="catalog-list.html">
										Dresses
									</a>
								</li>
								<li>
									<a href="catalog-list.html">
										Bags
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Shoulder Bags
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Falabella
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Becks
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Clutches
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Travel Bags
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Accessories
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Sunglasses
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Tech Cases
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Jewelry
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Stella
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Coats & Jackets
									</a>
								</li>
							</ul>
						</li>
						<li>
							<a href="catalog-list.html">
								Men
							</a>
							<i class="fa fa-angle-right"></i>
							<ul>
								<li>
									<a href="catalog-list.html">
										Jackets & Blazers
									</a>
								</li>
								<li>
									<a href="catalog-list.html">
										Pants & Shorts
									</a>
								</li>
								<li>
									<a href="catalog-list.html">
										Accessories
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Bags
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sunglasses
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Other Accessories
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Suiting
									</a>
								</li>
								<li>
									<a href="catalog-list.html">
										Shirts
									</a>
								</li>
							</ul>
						</li>
						<li>
							<a href="catalog-list.html">
								Kids
							</a>
							<i class="fa fa-angle-right"></i>
							<ul>
								<li>
									<a href="catalog-list.html">
										Girls
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Outerwear
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												T-Shirts
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Blouses & Shirts
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Pants & Shorts
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sleepwear & Underwear
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Skirts
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Boys
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Shoes & Accessories
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Jumpers & Cardigans
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Shirts
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Outerwear
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Swimwear
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Baby
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Baby Sets
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Dresses & All-In-One
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Pants & Shorts
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Shoes & Accessories
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												T-shirts
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Outerwear
											</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
						<li>
							<a href="catalog-list.html">
								Shoes
							</a>
							<i class="fa fa-angle-right"></i>
							<ul>
								<li>
									<a href="catalog-list.html">
										Women
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Elyse
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Odette
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Brody
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Flats
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sandals
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Men
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Casual Shoes
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sneakers
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sandals
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Boots
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Mules & Clogs
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Children's
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												Girls
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Boys
											</a>
										</li>
									</ul>
								</li>
								<li>
									<a href="catalog-list.html">
										Baby Shoe
									</a>
									<i class="fa fa-angle-right"></i>
									<ul>
										<li>
											<a href="catalog-list.html">
												First Walkers
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sneakers
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Boots
											</a>
										</li>
										<li>
											<a href="catalog-list.html">
												Sandals & Clogs
											</a>
										</li>
									</ul>
								</li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- Catalog menu - end -->

				<!-- Main menu - start -->
				<button type="button" class="mainmenu-btn">Menu</button>

				<ul class="mainmenu">
					<li>
						<a href="index.html">
							Home
						</a>
					</li>
					<li class="menu-item-has-children">
						<a href="catalog-list.html" class="active">
							Catalog <i class="fa fa-angle-down"></i>
						</a>
						<ul class="sub-menu">
							<li>
								<a href="catalog-list.html" class="active">
									Catalog List - Style 1
								</a>
							</li>
							<li>
								<a href="catalog-list-2.html">
									Catalog List - Style 2
								</a>
							</li>
							<li>
								<a href="catalog-gallery.html">
									Catalog Gallery - Style 1
								</a>
							</li>
							<li>
								<a href="catalog-gallery-2.html">
									Catalog Gallery - Style 2
								</a>
							</li>
							<li>
								<a href="catalog-table.html">
									Catalog Table
								</a>
							</li>
						</ul>
					</li>
					<li class="menu-item-has-children">
						<a href="product.html">
							Product <i class="fa fa-angle-down"></i>
						</a>
						<ul class="sub-menu">
							<li>
								<a href="product.html">
									Product - Style 1 (Slider)
								</a>
							</li>
							<li>
								<a href="product-2.html">
									Product - Style 2 (Scroll)
								</a>
							</li>
						</ul>
					</li>
					<li>
						<a href="elements.html">
							Elements
						</a>
					</li>
					<li class="menu-item-has-children">
						<a href="blog.html">
							Blog <i class="fa fa-angle-down"></i>
						</a>
						<ul class="sub-menu">
							<li>
								<a href="blog.html">
									Blog - Style 1
								</a>
							</li>
							<li>
								<a href="blog-2.html">
									Blog - Style 2
								</a>
							</li>
							<li>
								<a href="post.html">
									Single Post
								</a>
							</li>
						</ul>
					</li>
					<li class="menu-item-has-children">
						<a href="#">
							Pages <i class="fa fa-angle-down"></i>
						</a>
						<ul class="sub-menu">
							<li>
								<a href="contacts.html">
									Contacts
								</a>
							</li>
							<li>
								<a href="cart.html">
									Cart
								</a>
							</li>
							<li>
								<a href="auth.html">
									Authorization
								</a>
							</li>
							<li>
								<a href="compare.html">
									Compare
								</a>
							</li>
							<li>
								<a href="wishlist.html">
									Wishlist
								</a>
							</li>
							<li>
								<a href="404.html">
									Error 404
								</a>
							</li>
						</ul>
					</li>
					<li class="mainmenu-more">
						<span>...</span>
						<ul class="mainmenu-sub"></ul>
					</li>
				</ul>
				<!-- Main menu - end -->

				<!-- Search - start -->
				<div class="topsearch">
					<a id="topsearch-btn" class="topsearch-btn" href="#"><i class="fa fa-search"></i></a>
					<form class="topsearch-form" action="#">
						<input type="text" placeholder="Search products">
						<button type="submit"><i class="fa fa-search"></i></button>
					</form>
				</div>
				<!-- Search - end -->

			</nav>		</div>
	</div>
	<!-- Topmenu - end -->

</header>
<!-- Header - end -->


<!-- Main Content - start -->
<main>
	<section class="container">


		<ul class="b-crumbs">
			<li>
				<a href="index.html">
					Home
				</a>
			</li>
			<li>
				<a href="catalog-list.html">
					Catalog
				</a>
			</li>
			<li>
				<span>Women</span>
			</li>
		</ul>
		<h1 class="main-ttl"><span>Women</span></h1>
		<!-- Catalog Sidebar - start -->
		<div class="section-sb">

			<!-- Catalog Categories - start -->
			<div class="section-sb-current">
				<h3><a href="catalog-list.html">Women <span id="section-sb-toggle" class="section-sb-toggle"><span class="section-sb-ico"></span></span></a></h3>
				<ul class="section-sb-list" id="section-sb-list">
					<li class="categ-1">
						<a href="catalog-list.html">
							<span class="categ-1-label">Knitwear</span>
						</a>
					</li>
					<li class="categ-1">
						<a href="catalog-list.html">
							<span class="categ-1-label">Dresses</span>
						</a>
					</li>
					<li class="categ-1 has_child">
						<a href="catalog-list.html">
							<span class="categ-1-label">Bags</span>
							<span class="section-sb-toggle"><span class="section-sb-ico"></span></span>
						</a>
						<ul>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Shoulder Bags</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Falabella</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Becks</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Clutches</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Travel Bags</span>
								</a>
							</li>
						</ul>
					</li>
					<li class="categ-1 has_child">
						<a href="catalog-list.html">
							<span class="categ-1-label">Accessories</span>
							<span class="section-sb-toggle"><span class="section-sb-ico"></span></span>
						</a>
						<ul>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Sunglasses</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Tech Cases</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Jewelry</span>
								</a>
							</li>
							<li class="categ-2">
								<a href="catalog-list.html">
									<span class="categ-2-label">Stella</span>
								</a>
							</li>
						</ul>
					</li>
					<li class="categ-1">
						<a href="catalog-list.html">
							<span class="categ-1-label">Coats & Jackets</span>
						</a>
					</li>
				</ul>
			</div>
			<!-- Catalog Categories - end -->

			<!-- Filter - start -->
			<div class="section-filter">
				<button id="section-filter-toggle" class="section-filter-toggle" data-close="Hide Filter" data-open="Show Filter">
					<span>Show Filter</span> <i class="fa fa-angle-down"></i>
				</button>
				<div class="section-filter-cont">
					<div class="section-filter-price">
						<div class="range-slider section-filter-price" data-min="0" data-max="1000" data-from="200" data-to="800" data-prefix="$" data-grid="false"></div>
					</div>
					<div class="section-filter-item">
						<p class="section-filter-ttl">Style <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<p class="section-filter-field">
								<input id="section-filter-checkbox2-1" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox2-1">Work</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox2-2" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox2-2">Vintage</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox2-3" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox2-3">Cute</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox2-4" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox2-4">Novelty</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox2-5" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox2-5">Brief</label>
							</p>
						</div>
					</div>
					<div class="section-filter-item opened">
						<p class="section-filter-ttl">Material <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-1" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-1">Cotton</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-2" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-2">Spandex</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-3" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-3">Polyester</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-4" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-4">Acetate</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-5" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-5">Microfiber</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-6" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-6">Silk</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox3-7" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox3-7">Fur</label>
							</p>
						</div>
					</div>
					<div class="section-filter-item opened">
						<p class="section-filter-ttl">Color <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<ul class="section-filter-color">
								<li class="active"><img src="img/color/red.jpg" alt="Red"></li>
								<li><img src="img/color/blue.jpg" alt="Blue"></li>
								<li><img src="img/color/green.jpg" alt="Green"></li>
								<li><img src="img/color/yellow.jpg" alt="Yellow"></li>
								<li><img src="img/color/purple.jpg" alt="Purple"></li>
							</ul>
						</div>
					</div>
					<div class="section-filter-item opened">
						<p class="section-filter-ttl">Decoration <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<div class="section-filter-select">
								<select data-placeholder="Decoration" class="chosen-select">
									<option>Pattern</option>
									<option>Pockets</option>
									<option>Button</option>
									<option>Beading</option>
									<option>LOGO</option>
									<option>Spliced</option>
									<option>Letter</option>
									<option>Pleated</option>
									<option>Appliques</option>
									<option>Bow</option>
									<option>Criss-Cross</option>
									<option>Crystal</option>
									<option>Draped</option>
									<option>Embroidery</option>
									<option>Feathers</option>
									<option>Fur</option>
									<option>Flowers</option>
									<option>Lace</option>
									<option>Pearls</option>
									<option>Ruched</option>
									<option>Ruffles</option>
									<option>Sashes</option>
									<option>Ribbons</option>
									<option>Sequined</option>
									<option>Tassel</option>
									<option>Rivet</option>
									<option>Hole</option>
									<option>Hollow Out</option>
									<option>Embroidered Flares</option>
									<option>Cuffs</option>
									<option>Patches</option>
									<option>Fake Zippers</option>
									<option>Bleached</option>
									<option>Ripped</option>
									<option>Washed</option>
									<option>Patchwork</option>
									<option>Scratched</option>
									<option>Side Stripe</option>
									<option>None</option>
									<option>Character</option>
									<option>Other</option>
									<option>Badge</option>
									<option>Offset printing</option>
									<option>Patch pocket</option>
								</select>
							</div>
						</div>
					</div>
					<div class="section-filter-item opened">
						<p class="section-filter-ttl">Manufacturer country <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<div class="section-filter-select">
								<select data-placeholder="Manufacturer country" class="chosen-select" multiple>
									<optgroup label="EUROPE">
										<option>Albania</option>
										<option>Andorra</option>
										<option>Armenia</option>
										<option>Austria</option>
										<option>Azerbaijan</option>
										<option>Belarus</option>
										<option>Belgium</option>
										<option>Bosnia and Herzegovina</option>
										<option>Bulgaria</option>
										<option>Croatia</option>
										<option>Cyprus</option>
										<option>Czech Republic</option>
										<option>Denmark</option>
										<option>Estonia</option>
										<option>Finland</option>
										<option>France</option>
										<option>Georgia</option>
										<option>Germany</option>
										<option>Greece</option>
										<option>Hungary</option>
										<option>Iceland</option>
										<option>Ireland</option>
										<option>Italy</option>
										<option>Latvia</option>
										<option>Liechtenstein</option>
										<option>Lithuania</option>
										<option>Luxembourg</option>
										<option>Macedonia</option>
										<option>Malta</option>
										<option>Moldova</option>
										<option>Monaco</option>
										<option>Montenegro</option>
										<option>Netherlands</option>
										<option>Norway</option>
										<option>Poland</option>
										<option>Portugal</option>
										<option>Romania</option>
										<option>San Marino</option>
										<option>Serbia</option>
										<option>Slovakia</option>
										<option>Slovenia</option>
										<option>Spain</option>
										<option>Sweden</option>
										<option>Switzerland</option>
										<option>Ukraine</option>
										<option>United Kingdom</option>
										<option>Vatican City</option>
									</optgroup>
									<optgroup label="ASIA">
										<option>Afghanistan</option>
										<option>Bahrain</option>
										<option>Bangladesh</option>
										<option>Bhutan</option>
										<option>Brunei</option>
										<option>Burma (Myanmar)</option>
										<option>Cambodia</option>
										<option>China</option>
										<option>East Timor</option>
										<option>India</option>
										<option>Indonesia</option>
										<option>Iran</option>
										<option>Iraq</option>
										<option>Israel</option>
										<option>Japan</option>
										<option>Jordan</option>
										<option>Kazakhstan</option>
										<option>Korea, North</option>
										<option>Korea, South</option>
										<option>Kuwait</option>
										<option>Kyrgyzstan</option>
										<option>Laos</option>
										<option>Lebanon</option>
										<option>Malaysia</option>
										<option>Maldives</option>
										<option>Mongolia</option>
										<option>Nepal</option>
										<option>Oman</option>
										<option>Pakistan</option>
										<option>Philippines</option>
										<option>Qatar</option>
										<option>Russian Federation</option>
										<option>Saudi Arabia</option>
										<option>Singapore</option>
										<option>Sri Lanka</option>
										<option>Syria</option>
										<option>Tajikistan</option>
										<option>Thailand</option>
										<option>Turkey</option>
										<option>Turkmenistan</option>
										<option>United Arab Emirates</option>
										<option>Uzbekistan</option>
										<option>Vietnam</option>
										<option>Yemen</option>
									</optgroup>
									<optgroup label="N. AMERICA">
										<option>Antigua and Barbuda</option>
										<option>Bahamas</option>
										<option>Barbados</option>
										<option>Belize</option>
										<option>Canada</option>
										<option>Costa Rica</option>
										<option>Cuba</option>
										<option>Dominica</option>
										<option>Dominican Republic</option>
										<option>El Salvador</option>
										<option>Grenada</option>
										<option>Guatemala</option>
										<option>Haiti</option>
										<option>Honduras</option>
										<option>Jamaica</option>
										<option>Mexico</option>
										<option>Nicaragua</option>
										<option>Panama</option>
										<option>Saint Kitts and Nevis</option>
										<option>Saint Lucia</option>
										<option>Saint Vincent and the Grenadines</option>
										<option>Trinidad and Tobago</option>
										<option>United States</option>
									</optgroup>
									<optgroup label="S. AMERICA">
										<option>Argentina</option>
										<option>Bolivia</option>
										<option>Brazil</option>
										<option>Chile</option>
										<option>Colombia</option>
										<option>Ecuador</option>
										<option>Guyana</option>
										<option>Paraguay</option>
										<option>Peru</option>
										<option>Suriname</option>
										<option>Uruguay</option>
										<option>Venezuela</option>
									</optgroup>
									<optgroup label="AFRICA">
										<option>Algeria</option>
										<option>Angola</option>
										<option>Benin</option>
										<option>Botswana</option>
										<option>Burkina</option>
										<option>Burundi</option>
										<option>Cameroon</option>
										<option>Cape Verde</option>
										<option>Central African Republic</option>
										<option>Chad</option>
										<option>Comoros</option>
										<option>Congo</option>
										<option>Congo</option>
										<option>Djibouti</option>
										<option>Egypt</option>
										<option>Equatorial Guinea</option>
										<option>Eritrea</option>
										<option>Ethiopia</option>
										<option>Gabon</option>
										<option>Gambia</option>
										<option>Ghana</option>
										<option>Guinea</option>
										<option>Guinea-Bissau</option>
										<option>Ivory Coast</option>
										<option>Kenya</option>
										<option>Lesotho</option>
										<option>Liberia</option>
										<option>Libya</option>
										<option>Madagascar</option>
										<option>Malawi</option>
										<option>Mali</option>
										<option>Mauritania</option>
										<option>Mauritius</option>
										<option>Morocco</option>
										<option>Mozambique</option>
										<option>Namibia</option>
										<option>Niger</option>
										<option>Nigeria</option>
										<option>Rwanda</option>
										<option>Sao Tome and Principe</option>
										<option>Senegal</option>
										<option>Seychelles</option>
										<option>Sierra Leone</option>
										<option>Somalia</option>
										<option>South Africa</option>
										<option>South Sudan</option>
										<option>Sudan</option>
										<option>Swaziland</option>
										<option>Tanzania</option>
										<option>Togo</option>
										<option>Tunisia</option>
										<option>Uganda</option>
										<option>Zambia</option>
										<option>Zimbabwe</option>
									</optgroup>
									<optgroup label="OCEANIA">
										<option>Australia</option>
										<option>Fiji</option>
										<option>Kiribati</option>
										<option>Marshall Islands</option>
										<option>Micronesia</option>
										<option>Nauru</option>
										<option>New Zealand</option>
										<option>Palau</option>
										<option>Papua New Guinea</option>
										<option>Samoa</option>
										<option>Solomon Islands</option>
										<option>Tonga</option>
										<option>Tuvalu</option>
										<option>Vanuatu</option>
									</optgroup>
								</select>
							</div>
						</div>
					</div>
					<div class="section-filter-item">
						<p class="section-filter-ttl">Pattern Type <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<p class="section-filter-field">
								<input id="section-filter-checkbox4-1" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox4-1">Solid</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox4-2" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox4-2">Patchwork</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox4-3" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox4-3">Dot</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox4-4" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox4-4">Print</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox4-5" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox4-5">Character</label>
							</p>
						</div>
					</div>
					<div class="section-filter-item">
						<p class="section-filter-ttl">Fit Type <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<p class="section-filter-field">
								<input id="section-filter-checkbox5-1" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox5-1">Loose</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox5-2" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox5-2">Skinny</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox5-3" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox5-3">Regular</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox5-4" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox5-4">Straight</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox5-5" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox5-5">Boot Cut</label>
							</p>
						</div>
					</div>
					<div class="section-filter-item opened">
						<p class="section-filter-ttl">Fabric Type <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<p class="section-filter-field">
								<input id="section-filter-radio1-1" value="on" type="radio" name="section-filter-radio1">
								<label class="section-filter-radio" for="section-filter-radio1-1">Velour</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-radio1-2" value="on" type="radio" name="section-filter-radio1">
								<label class="section-filter-radio" for="section-filter-radio1-2">Batik</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-radio1-3" value="on" type="radio" name="section-filter-radio1">
								<label class="section-filter-radio" for="section-filter-radio1-3">Chiffon</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-radio1-4" value="on" type="radio" name="section-filter-radio1">
								<label class="section-filter-radio" for="section-filter-radio1-4">Broadcloth</label>
							</p>
						</div>
					</div>
					<div class="section-filter-item">
						<p class="section-filter-ttl">Wash <i class="fa fa-angle-down"></i></p>
						<div class="section-filter-fields">
							<p class="section-filter-field">
								<input id="section-filter-checkbox6-1" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox6-1">Colored</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox6-2" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox6-2">Light</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox6-3" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox6-3">Medium</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox6-4" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox6-4">Stonewashed</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox6-5" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox6-5">White</label>
							</p>
							<p class="section-filter-field">
								<input id="section-filter-checkbox6-6" value="on" type="checkbox">
								<label class="section-filter-checkbox" for="section-filter-checkbox6-6">Distrressed</label>
							</p>
						</div>
					</div>
					<div class="section-filter-buttons">
						<input class="btn btn-themes" id="set_filter" name="set_filter" value="Apply filter" type="button">
						<input class="btn btn-link" id="del_filter" name="del_filter" value="Reset" type="button">
					</div>
				</div>
			</div>
			<!-- Filter - end -->

		</div>
		<!-- Catalog Sidebar - end -->
		<!-- Catalog Items | List V1 - start -->
		<div class="section-cont">

			<!-- Catalog Topbar - start -->
			<div class="section-top">

				<!-- View Mode -->
				<ul class="section-mode">
					<li class="section-mode-gallery"><a title="View mode: Gallery" href="catalog-gallery.html"></a></li>
					<li class="section-mode-list active"><a title="View mode: List" href="catalog-list.html"></a></li>
					<li class="section-mode-table"><a title="View mode: Table" href="catalog-table.html"></a></li>
				</ul>

				<!-- Sorting -->
				<div class="section-sortby">
					<p>default sorting</p>
					<ul>
						<li>
							<a href="#">sort by popularity</a>
						</li>
						<li>
							<a href="#">low price to high</a>
						</li>
						<li>
							<a href="#">high price to low</a>
						</li>
						<li>
							<a href="#">by title A <i class="fa fa-angle-right"></i> Z</a>
						</li>
						<li>
							<a href="#">by title Z <i class="fa fa-angle-right"></i> A</a>
						</li>
						<li>
							<a href="#">default sorting</a>
						</li>
					</ul>
				</div>

				<!-- Count per page -->
				<div class="section-count">
					<p>12</p>
					<ul>
						<li><a href="#">12</a></li>
						<li><a href="#">24</a></li>
						<li><a href="#">48</a></li>
					</ul>
				</div>

			</div>
			<!-- Catalog Topbar - end -->
			<div class="prod-items section-items">
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x311" alt="Adipisci aperiam commodi"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Adipisci aperiam commodi</a></h3>
						<div class="prodlist-i-txt">
							Quisquam totam quas veritatis dolor voluptates, laudantium repellendus. Cupiditate repellat tempora consequatur sequi, neque					</div>
						<div class="prodlist-i-skuwrap">
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Color</p>
								<ul class="prodlist-i-skucolor">
									<li class="active"><img src="img/color/blue.jpg" alt=""></li>
									<li><img src="img/color/red.jpg" alt=""></li>
									<!--<li><img src="img/color/yellow.jpg" alt=""></li>-->
									<!--<li><img src="img/color/purple.jpg" alt=""></li>-->
									<li><img src="img/color/green.jpg" alt=""></li>
								</ul>
							</div>
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Clothes sizes</p>
								<div class="offer-props-select">
									<p>XS</p>
									<ul>
										<li><a href="#">S</a></li>
										<li><a href="#">M</a></li>
										<li><a href="#">L</a></li>
										<li class="active"><a href="#">XS</a></li>
										<li><a href="#">XL</a></li>
										<li><a href="#">XXL</a></li>
										<li><a href="#">XXXL</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$59</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Exterior</b> Silt Pocket</li>
							<li><b>Material</b> PU</li>
							<li><b>Occasion</b> Versatile</li>
							<li><b>Shape</b> Casual Tote</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Style</b> American Style</li>
							<li><b>Hardness</b> Soft</li>
							<li><b>Decoration</b> None</li>
							<li><b>Closure Type</b> Zipper</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x366" alt="Nulla numquam obcaecati"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Nulla numquam obcaecati</a></h3>
						<div class="prodlist-i-txt">
							Assumenda deserunt eligendi qui, est error, sed dolorum magnam sequi totam recusandae nam minima accusamus illo dolores adipisci non fugit quis consequatur					</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$48</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Material</b> Cotton,Polyester</li>
							<li><b>Sleeve Length</b> Short</li>
							<li><b>Tops Type</b> Tees</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Style</b> Casual</li>
							<li><b>Hooded</b> No</li>
							<li><b>Collar</b> V-Neck</li>
							<li><b>Sleeve Style</b> General</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/370x300" alt="Dignissimos eaque earum"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Dignissimos eaque earum</a></h3>
						<div class="prodlist-i-txt">
							Deserunt sapiente mollitia expedita, quia blanditiis ipsam dignissimos? A consectetur tempora dolorum quisquam assumenda, quidem ratione accusamus cupiditate commodi					</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$37</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Gender</b> Unisex</li>
							<li><b>Material</b> Wool, Polyester</li>
							<li><b>Style</b> Casual</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Hats size</b> Oversize</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x345" alt="Porro quae quasi"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Porro quae quasi</a></h3>
						<div class="prodlist-i-txt">
							Rerum est facere consequuntur, vero error deleniti totam vitae, eius necessitatibus, deserunt cupiditate quae iusto sint quasi, id officiis! Labore amet, architecto dolorum rerum voluptates					</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$85</b>
															<del>$110</del>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Sleeve Length</b> Full</li>
							<li><b>Sleeve Style</b> Long sleeve</li>
							<li><b>Collar</b> V-Neck</li>
							<li><b>Fabric Type</b> Broadcloth</li>
							<li><b>Material</b> Cotton,Spandex</li>
							<li><b>Hooded</b> No</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Gender</b> Men</li>
							<li><b>Style</b> Fashion</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/378x300" alt="Sunt temporibus velit"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Sunt temporibus velit</a></h3>
						<div class="prodlist-i-txt">
							Excepturi odit perferendis assumenda nisi cum, sunt autem quos odio quibusdam ipsa, molestias eum officia					</div>
						<div class="prodlist-i-skuwrap">
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Color</p>
								<ul class="prodlist-i-skucolor">
									<li class="active"><img src="img/color/blue.jpg" alt=""></li>
									<li><img src="img/color/red.jpg" alt=""></li>
									<!--<li><img src="img/color/yellow.jpg" alt=""></li>-->
									<!--<li><img src="img/color/purple.jpg" alt=""></li>-->
									<li><img src="img/color/green.jpg" alt=""></li>
								</ul>
							</div>
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Clothes sizes</p>
								<div class="offer-props-select">
									<p>XS</p>
									<ul>
										<li><a href="#">S</a></li>
										<li><a href="#">M</a></li>
										<li><a href="#">L</a></li>
										<li class="active"><a href="#">XS</a></li>
										<li><a href="#">XL</a></li>
										<li><a href="#">XXL</a></li>
										<li><a href="#">XXXL</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$115</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Gender</b> Men</li>
							<li><b>Shaft Material</b> Flock</li>
							<li><b>Lining Material</b> Plush</li>
							<li><b>Insole Material</b> Rubber</li>
							<li><b>Season</b> Winter</li>
							<li><b>With Platforms</b> No</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Boot Height</b> Ankle</li>
							<li><b>Closure Type</b> Lace-Up</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x394" alt="Harum illum incidunt"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Harum illum incidunt</a></h3>
						<div class="prodlist-i-txt">
							Distinctio laborum quos fugit nobis mollitia rem sit saepe perspiciatis qui					</div>
						<div class="prodlist-i-skuwrap">
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Clothes sizes</p>
								<div class="offer-props-select">
									<p>XS</p>
									<ul>
										<li><a href="#">S</a></li>
										<li><a href="#">M</a></li>
										<li><a href="#">L</a></li>
										<li class="active"><a href="#">XS</a></li>
										<li><a href="#">XL</a></li>
										<li><a href="#">XXL</a></li>
										<li><a href="#">XXXL</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$130</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Outerwear Type</b> Jackets</li>
							<li><b>Sleeve Style</b> Regular</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Material</b> Polyester,Cotton</li>
							<li><b>Hooded</b> Yes</li>
							<li><b>Style</b> Casual</li>
							<li><b>Collar</b> Turn-down Collar</li>
							<li><b>Decoration</b> Pockets</li>
							<li><b>Gender</b> Men</li>
							<li><b>Closure Type</b> Zipper</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x303" alt="Reprehenderit rerum"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Reprehenderit rerum</a></h3>
						<div class="prodlist-i-skuwrap">
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Color</p>
								<ul class="prodlist-i-skucolor">
									<li class="active"><img src="img/color/blue.jpg" alt=""></li>
									<li><img src="img/color/red.jpg" alt=""></li>
									<!--<li><img src="img/color/yellow.jpg" alt=""></li>-->
									<!--<li><img src="img/color/purple.jpg" alt=""></li>-->
									<li><img src="img/color/green.jpg" alt=""></li>
								</ul>
							</div>
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Clothes sizes</p>
								<div class="offer-props-select">
									<p>XS</p>
									<ul>
										<li><a href="#">S</a></li>
										<li><a href="#">M</a></li>
										<li><a href="#">L</a></li>
										<li class="active"><a href="#">XS</a></li>
										<li><a href="#">XL</a></li>
										<li><a href="#">XXL</a></li>
										<li><a href="#">XXXL</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$210</b>
															<del>$240</del>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Outerwear Type</b> Jackets</li>
							<li><b>Sleeve Style</b> Regular</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Material</b> Polyester,Cotton</li>
							<li><b>Hooded</b> Yes</li>
							<li><b>Style</b> Casual</li>
							<li><b>Collar</b> Turn-down Collar</li>
							<li><b>Decoration</b> Pockets</li>
							<li><b>Gender</b> Boys</li>
							<li><b>Closure Type</b> Zipper</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x588" alt="Quae quasi adipisci alias"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Quae quasi adipisci alias</a></h3>
						<div class="prodlist-i-txt">
							Cum nihil saepe itaque, quibusdam quos libero, et possimus rerum ratione similique					</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$85</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Gender</b> Women</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Color Style</b> Natural Color</li>
							<li><b>Material</b> Polyester</li>
							<li><b>Length</b> LongHooded</li>
							<li><b>Fabric Type</b> Woven</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x416" alt="Maxime molestias necessitatibus nobis"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Maxime molestias necessitatibus nobis</a></h3>
						<div class="prodlist-i-txt">
							Tempora eius in voluptates quos dolorem, omnis consequatur quae, autem eligendi totam ex esse dolores accusamus					</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$95</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Outerwear Type</b> Jackets</li>
							<li><b>Sleeve Style</b> Regular</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Material</b> Polyester,Cotton</li>
							<li><b>Hooded</b> Yes</li>
							<li><b>Style</b> Casual</li>
							<li><b>Collar</b> Turn-down Collar</li>
							<li><b>Decoration</b> Pockets</li>
							<li><b>Gender</b> Men</li>
							<li><b>Closure Type</b> Zipper</li>
						</ul>
					</div>

					<div class="prod-sticker">
						<p class="prod-sticker-3">-30%</p><p class="prod-sticker-4 countdown" data-date="29 Jan 2017, 14:30:00"></p>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x480" alt="Facilis illum"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Facilis illum</a></h3>
						<div class="prodlist-i-txt">
							Quis temporibus hic reprehenderit explicabo odio earum maxime cupiditate mollitia					</div>
						<div class="prodlist-i-skuwrap">
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Color</p>
								<ul class="prodlist-i-skucolor">
									<li class="active"><img src="img/color/blue.jpg" alt=""></li>
									<li><img src="img/color/red.jpg" alt=""></li>
									<!--<li><img src="img/color/yellow.jpg" alt=""></li>-->
									<!--<li><img src="img/color/purple.jpg" alt=""></li>-->
									<li><img src="img/color/green.jpg" alt=""></li>
								</ul>
							</div>
						</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$150</b>
															<del>$180</del>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Outerwear Type</b> Down & Parkas</li>
							<li><b>Closure Type</b> Zipper</li>
							<li><b>Filling</b> Cotton</li>
							<li><b>Fabric Type</b> Woven</li>
							<li><b>Clothing Length</b> Regular</li>
							<li><b>Material</b> Polyester</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Decoration</b> Pockets, Zippers</li>
							<li><b>Sleeve Length</b> Full</li>
							<li><b>Hooded</b> Yes</li>
						</ul>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/358x300" alt="Iusto labore laudantium"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Iusto labore laudantium</a></h3>
						<div class="prodlist-i-txt">
							Veniam, non harum voluptate dicta sit porro iste cumque eligendi					</div>
						<div class="prodlist-i-skuwrap">
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Color</p>
								<ul class="prodlist-i-skucolor">
									<li class="active"><img src="img/color/blue.jpg" alt=""></li>
									<li><img src="img/color/red.jpg" alt=""></li>
									<!--<li><img src="img/color/yellow.jpg" alt=""></li>-->
									<!--<li><img src="img/color/purple.jpg" alt=""></li>-->
									<li><img src="img/color/green.jpg" alt=""></li>
								</ul>
							</div>
							<div class="prodlist-i-skuitem">
								<p class="prodlist-i-skuttl">Clothes sizes</p>
								<div class="offer-props-select">
									<p>XS</p>
									<ul>
										<li><a href="#">S</a></li>
										<li><a href="#">M</a></li>
										<li><a href="#">L</a></li>
										<li class="active"><a href="#">XS</a></li>
										<li><a href="#">XL</a></li>
										<li><a href="#">XXL</a></li>
										<li><a href="#">XXXL</a></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$170</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Handbags Type</b> Shoulder Bags</li>
							<li><b>Exterior</b> Silt Pocket</li>
							<li><b>Material</b> Canvas</li>
							<li><b>Occasion</b> Versatile</li>
							<li><b>Shape</b> Casual Tote</li>
							<li><b>Pattern Type</b> Solid</li>
							<li><b>Style</b> Casual</li>
							<li><b>Hardness</b> Soft</li>
							<li><b>Decoration</b> None</li>
							<li><b>Closure Type</b> Zipper</li>
						</ul>
					</div>

					<div class="prod-sticker">
						<p class="prod-sticker-1">NEW</p>
					</div>
				</div>
				<div class="prodlist-i">
					<a class="prodlist-i-img" href="product.html"><!-- NO SPACE --><img src="http://placehold.it/300x504" alt="Fuga impedit inciduntipsa"><!-- NO SPACE --></a>
					<div class="prodlist-i-cont">
						<h3><a href="product.html">Fuga impedit inciduntipsa</a></h3>
						<div class="prodlist-i-txt">
							Praesentium iure inventore nostrum corporis illum, est asperiores accusamus, ducimus, accusantium natus					</div>
						<div class="prodlist-i-action">
							<p class="prodlist-i-qnt">
								<input value="1" type="text">
								<a href="#" class="prodlist-i-plus"><i class="fa fa-angle-up"></i></a>
								<a href="#" class="prodlist-i-minus"><i class="fa fa-angle-down"></i></a>
							</p>
							<p class="prodlist-i-addwrap">
								<a href="#" class="prodlist-i-add">Add to cart</a>
							</p>
						<span class="prodlist-i-price">
							<b>$80</b>
													</span>
						</div>
						<p class="prodlist-i-info">
							<a href="#" class="prodlist-i-favorites"><i class="fa fa-heart"></i> Add to wishlist</a>
							<a href="#" class="qview-btn prodlist-i-qview"><i class="fa fa-search"></i> Quick view</a>
							<a class="prodlist-i-compare" href="#"><i class="fa fa-bar-chart"></i> Compare</a>
						</p>
					</div>

					<div class="prodlist-i-props-wrap">
						<ul class="prodlist-i-props">
							<li><b>Gender</b> Women</li>
							<li><b>Silhouette</b> Sheath</li>
							<li><b>Material</b> Polyester</li>
							<li><b>Season</b> Autumn</li>
							<li><b>Style</b> Casual</li>
							<li><b>Waistline</b> Natural</li>
						</ul>
					</div>
				</div>
			</div>

			<!-- Pagination - start -->
			<ul class="pagi">
				<li class="active"><span>1</span></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li class="pagi-next"><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
			</ul>
			<!-- Pagination - end -->
		</div>

		<!-- Quick View Product - start -->
		<div class="qview-modal">
			<div class="prod-wrap">
				<a href="product.html">
					<h1 class="main-ttl">
						<span>Reprehenderit adipisci</span>
					</h1>
				</a>
				<div class="prod-slider-wrap">
					<div class="prod-slider">
						<ul class="prod-slider-car">
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x525">
									<img src="http://placehold.it/500x525" alt="">
								</a>
							</li>
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x591">
									<img src="http://placehold.it/500x591" alt="">
								</a>
							</li>
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x525">
									<img src="http://placehold.it/500x525" alt="">
								</a>
							</li>
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x722">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x722">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x722">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
							<li>
								<a data-fancybox-group="popup-product" class="fancy-img" href="http://placehold.it/500x722">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
						</ul>
					</div>
					<div class="prod-thumbs">
						<ul class="prod-thumbs-car">
							<li>
								<a data-slide-index="0" href="#">
									<img src="http://placehold.it/500x525" alt="">
								</a>
							</li>
							<li>
								<a data-slide-index="1" href="#">
									<img src="http://placehold.it/500x591" alt="">
								</a>
							</li>
							<li>
								<a data-slide-index="2" href="#">
									<img src="http://placehold.it/500x525" alt="">
								</a>
							</li>
							<li>
								<a data-slide-index="3" href="#">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
							<li>
								<a data-slide-index="4" href="#">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
							<li>
								<a data-slide-index="5" href="#">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
							<li>
								<a data-slide-index="6" href="#">
									<img src="http://placehold.it/500x722" alt="">
								</a>
							</li>
						</ul>
					</div>
				</div>

				<div class="prod-cont">
					<p class="prod-actions">
						<a href="#" class="prod-favorites"><i class="fa fa-heart"></i> Add to Wishlist</a>
						<a href="#" class="prod-compare"><i class="fa fa-bar-chart"></i> Compare</a>
					</p>
					<div class="prod-skuwrap">
						<p class="prod-skuttl">Color</p>
						<ul class="prod-skucolor">
							<li class="active">
								<img src="img/color/blue.jpg" alt="">
							</li>
							<li>
								<img src="img/color/red.jpg" alt="">
							</li>
							<li>
								<img src="img/color/green.jpg" alt="">
							</li>
							<li>
								<img src="img/color/yellow.jpg" alt="">
							</li>
							<li>
								<img src="img/color/purple.jpg" alt="">
							</li>
						</ul>
						<p class="prod-skuttl">Sizes</p>
						<div class="offer-props-select">
							<p>XL</p>
							<ul>
								<li><a href="#">XS</a></li>
								<li><a href="#">S</a></li>
								<li><a href="#">M</a></li>
								<li class="active"><a href="#">XL</a></li>
								<li><a href="#">L</a></li>
								<li><a href="#">4XL</a></li>
								<li><a href="#">XXL</a></li>
							</ul>
						</div>
					</div>
					<div class="prod-info">
						<p class="prod-price">
							<b class="item_current_price">$238</b>
						</p>
						<p class="prod-qnt">
							<input type="text" value="1">
							<a href="#" class="prod-plus"><i class="fa fa-angle-up"></i></a>
							<a href="#" class="prod-minus"><i class="fa fa-angle-down"></i></a>
						</p>
						<p class="prod-addwrap">
							<a href="#" class="prod-add">Add to cart</a>
						</p>
					</div>
					<ul class="prod-i-props">
						<li>
							<b>SKU</b> 05464207
						</li>
						<li>
							<b>Manufacturer</b> Mayoral
						</li>
						<li>
							<b>Material</b> Cotton
						</li>
						<li>
							<b>Pattern Type</b> Print
						</li>
						<li>
							<b>Wash</b> Colored
						</li>
						<li>
							<b>Style</b> Cute
						</li>
						<li>
							<b>Color</b> Blue, Red
						</li>
						<li><a href="#" class="prod-showprops">All Features</a></li>
					</ul>
				</div>
			</div>
		</div>
		<!-- Quick View Product - end -->
	</section>
</main>
<!-- Main Content - end -->


<!-- Footer - start -->
<footer class="footer-wrap">
	<div class="footer-top">
		<div class="container">
			<div class="row">
				<div class="companyinfo">
					<a href="index.html">
						<img src="img/logo-b.png" alt="AllStore - MultiConcept eCommerce Responsive HTML5 Template">
						AllStore - MultiConcept eCommerce Responsive HTML5 Template
					</a>
				</div>
				<div class="f-block-list">
					<div class="f-block-wrap">
						<div class="f-block">
							<a href="#" class="f-block-btn" data-id="#f-block-modal-1">
								<div class="iframe-img">
									<img src="http://placehold.it/300x127" alt="About us">
								</div>
								<div class="overlay-icon">
									<i class="fa fa-info-circle"></i>
								</div>
							</a>
							<p class="f-info-ttl">About us</p>
							<p>Shipping and payment information.</p>
						</div>
					</div>
					<div class="f-block-wrap">
						<div class="f-block">
							<a href="#" class="f-block-btn" data-id="#f-block-modal-2">
								<div class="iframe-img">
									<img src="http://placehold.it/300x127" alt="Ask questions">
								</div>
								<div class="overlay-icon">
									<i class="fa fa-phone"></i>
								</div>
							</a>
							<p class="f-info-ttl">Ask questions</p>
							<p>We call back within 10 minutes</p>
						</div>
					</div>
					<div class="f-block-wrap">
						<div class="f-block">
							<a href="#" class="f-block-btn" data-id="#f-block-modal-3" data-content="<iframe width='853' height='480' src='https://www.youtube.com/embed/kaOVHSkDoPY?rel=0&amp;showinfo=0' allowfullscreen></iframe>">
								<div class="iframe-img">
									<img src="http://placehold.it/300x127" alt="Video (2 min)">
								</div>
								<div class="overlay-icon">
									<i class="fa fa-play-circle"></i>
								</div>
							</a>
							<p class="f-info-ttl">Video (2 min)</p>
							<p>Watch a video about our store</p>
						</div>
					</div>
					<div class="f-block-wrap">
						<div class="f-block">
							<a href="#" class="f-block-btn" data-id="#f-block-modal-4">
								<div class="iframe-img">
									<img src="http://placehold.it/300x127" alt="Our address">
								</div>
								<div class="overlay-icon">
									<i class="fa fa-map-marker"></i>
								</div>
							</a>
							<p class="f-info-ttl">Our address</p>
							<p>Spain, Madrid, 45</p>
						</div>
					</div>
				</div>

				<div class="stylization f-block-modal f-block-modal-content" id="f-block-modal-1">
					<img class="f-block-modal-img" src="http://placehold.it/500x334" alt="About us">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nam natus iste ullam vero, tenetur ab ipsa consectetur deleniti officiis ex debitis incidunt alias voluptatum, maxime placeat dolores veniam sunt at atque velit, soluta. Neque ea alias quia provident molestias, ratione aut esse placeat beatae sequi sed laudantium. Unde animi nihil esse, repellendus exercitationem dicta harum ab labore, voluptates explicabo in, quidem dolorum voluptas!
				</div>
				<div class="stylization f-block-modal f-block-modal-callback" id="f-block-modal-2">
					<div class="modalform">
						<form action="#" method="POST" class="form-validate">
							<p class="modalform-ttl">Callback</p>
							<input type="text" placeholder="Your name" data-required="text" name="name">
							<input type="text" placeholder="Your phone" data-required="text" name="phone">
							<button type="submit"><i class="fa fa-paper-plane"></i> Send</button>
						</form>
					</div>
				</div>
				<div class="stylization f-block-modal f-block-modal-video" id="f-block-modal-3">

				</div>
				<div class="stylization f-block-modal f-block-modal-map" id="f-block-modal-4">
					<div class="allstore-gmap">
						<div class="marker" data-zoom="15" data-lat="-37.81485261872975" data-lng="144.95655298233032" data-marker="img/marker.png">534-540 Little Bourke St, Melbourne VIC 3000, Australia</div>
					</div>
				</div>
				<div class="f-delivery">
					<img src="img/map.png" alt="">
					<h4>Free delivery in London</h4>
					<p>We will deliver within 1 hour</p>
				</div>
			</div>
		</div>
	</div>

	<div class="container f-menu-list">
		<div class="row">
			<div class="f-menu">
				<h3>
					About us
				</h3>
				<ul class="nav nav-pills nav-stacked">
					<li class="active"><a href="index.html">Home</a></li>
					<li><a href="catalog-list.html">Catalog</a></li>
					<li><a href="elements.html">Elements</a></li>
					<li><a href="blog.html">Blog</a></li>
					<li><a href="contacts.html">Contacts</a></li>
				</ul>
			</div>
			<div class="f-menu">
				<h3>
					Shop
				</h3>
				<ul class="nav nav-pills nav-stacked">
					<li><a href="catalog-list.html">Women</a></li>
					<li><a href="catalog-list.html">Men</a></li>
					<li><a href="catalog-list.html">Kids</a></li>
					<li><a href="catalog-list.html">Shoes</a></li>
					<li><a href="catalog-list.html">Accessories</a></li>
				</ul>
			</div>
			<div class="f-menu">
				<h3>
					Information
				</h3>
				<ul class="nav nav-pills nav-stacked">
					<li><a href="blog.html">Blog</a></li>
					<li><a href="blog.html">News</a></li>
					<li><a href="reviews.html">Reviews</a></li>
					<li><a href="blog.html">Articles</a></li>
					<li><a href="contacts.html">Contacts</a></li>
				</ul>
			</div>
			<div class="f-menu">
				<h3>
					Pages
				</h3>
				<ul class="nav nav-pills nav-stacked">
					<li><a href="contacts.html">About us</a></li>
					<li><a href="contacts.html">Delivery</a></li>
					<li><a href="contacts.html">Guarantees</a></li>
					<li><a href="contacts.html">Contacts</a></li>
					<li><a href="404.html">Page 404</a></li>
				</ul>
			</div>
			<div class="f-subscribe">
				<h3>Subscribe to news</h3>
				<form class="f-subscribe-form" action="#">
					<input placeholder="Your e-mail" type="text">
					<button type="submit"><i class="fa fa-paper-plane"></i></button>
				</form>
				<p>Enter your email address if you want to receive our newsletter. Subscribe now!</p>
			</div>
		</div>
	</div>

	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<ul class="social-icons nav navbar-nav">
					<li>
						<a href="http://facebook.com/" rel="nofollow" target="_blank">
							<i class="fa fa-facebook"></i>
						</a>
					</li>
					<li>
						<a href="http://google.com/" rel="nofollow" target="_blank">
							<i class="fa fa-google-plus"></i>
						</a>
					</li>
					<li>
						<a href="http://twitter.com/" rel="nofollow" target="_blank">
							<i class="fa fa-twitter"></i>
						</a>
					</li>
					<li>
						<a href="http://vk.com/" rel="nofollow" target="_blank">
							<i class="fa fa-vk"></i>
						</a>
					</li>
					<li>
						<a href="http://instagram.com/" rel="nofollow" target="_blank">
							<i class="fa fa-instagram"></i>
						</a>
					</li>
				</ul>
				<div class="footer-copyright">
					<i><a href="https://themeforest.net/user/real-web?ref=real-web">Real-Web</a></i> © Copyright 2017
				</div>
			</div>
		</div>
	</div>

</footer>
<!-- Footer - end -->


<!-- jQuery plugins/scripts - start -->
<script src="js/jquery-1.11.2.min.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/fancybox/fancybox.js"></script>
<script src="js/fancybox/helpers/jquery.fancybox-thumbs.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/swiper.jquery.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/progressbar.min.js"></script>
<script src="js/ion.rangeSlider.min.js"></script>
<script src="js/chosen.jquery.min.js"></script>
<script src="js/jQuery.Brazzers-Carousel.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDhAYvx0GmLyN5hlf6Uv_e9pPvUT3YpozE"></script>
<script src="js/gmap.js"></script>
<!-- jQuery plugins/scripts - end -->

</body>
</html>