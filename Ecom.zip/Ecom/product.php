<?php

$myid = $_GET['id'];

include('./template/header.php');
include( './config.php' );
$db = new Dbconnection();
$con = $db->getConnection();

$query = " SELECT * FROM product ";
$stmt = $con->prepare($query);
$stmt->execute();
$record = $stmt->fetchAll(PDO::FETCH_OBJ);

$query1 = 'select * from product where pid = ?';
$stmt1 = $con->prepare( $query1);
$stmt1->bindParam(1, $myid);
$stmt1->execute();
$result = $stmt1->fetch();
?>



<!-- Main Content - start -->
<main>
	<section class="container">


		<ul class="b-crumbs">
			<li>
				<a href="index.php">
					Home
				</a>
			</li>
			<li>
				<a href="catalog-list.php">
					Catalog
				</a>
			</li>
			<li>
				<a href="catalog-list.php">
					Women
				</a>
			</li>
			<li>
				<span>Aperiam nihil veniam</span>
			</li>
		</ul>
		<h1 class="main-ttl"><span><?php echo $result['pname']  ?></span></h1>
		<!-- Single Product - start -->
		<div class="prod-wrap">

			<!-- Product Images -->
			<div class="prod-slider-wrap">
				<div class="prod-slider">
					<ul class="prod-slider-car">
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="">
							<img src='<?php echo " ./upload/$result->pthumb" ?>' alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-fancybox-group="product" class="fancy-img" href="http://placehold.it/500x722">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
					</ul>
				</div>
				<div class="prod-thumbs">
					<ul class="prod-thumbs-car">
						<li>
							<a data-slide-index="0" href="#">
								<img src="" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="1" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="2" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="3" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="4" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="5" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="6" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
						<li>
							<a data-slide-index="7" href="#">
								<img src="http://placehold.it/500x722" alt="">
							</a>
						</li>
					</ul>
				</div>
			</div>

			<!-- Product Description/Info -->
			<div class="prod-cont">
				<div class="prod-cont-txt">
					<?php echo $result['pshortdesc'] ?>
				</div>
				<p class="prod-actions">
					<a href="#" class="prod-favorites"><i class="fa fa-heart"></i> Wishlist</a>
					<a href="#" class="prod-compare"><i class="fa fa-bar-chart"></i> Compare</a>
				</p>
				<div class="prod-skuwrap">
					<p class="prod-skuttl">Color</p>
					<ul class="prod-skucolor">
						<li class="active">
							<img src="img/color/blue.jpg" alt="">
						</li>
						<li>
							<img src="img/color/red.jpg" alt="">
						</li>
						<li>
							<img src="img/color/green.jpg" alt="">
						</li>
						<li>
							<img src="img/color/yellow.jpg" alt="">
						</li>
						<li>
							<img src="img/color/purple.jpg" alt="">
						</li>
					</ul>
					<p class="prod-skuttl">CLOTHING SIZES</p>
					<div class="offer-props-select">
						<p>XL</p>
						<ul>
							<li><a href="#">XS</a></li>
							<li><a href="#">S</a></li>
							<li><a href="#">M</a></li>
							<li class="active"><a href="#">XL</a></li>
							<li><a href="#">L</a></li>
							<li><a href="#">4XL</a></li>
							<li><a href="#">XXL</a></li>
						</ul>
					</div>
				</div>
				<div class="prod-info">
					<p class="prod-price">
						<b class="item_current_price"><?php echo $result['pprice']  ?></b>
					</p>
					<!-- <p class="prod-qnt">
						<input value="1" type="number">
						<a href="#" class="prod-plus"><i class="fa fa-angle-up"></i></a>
						<a href="#" class="prod-minus"><i class="fa fa-angle-down"></i></a>
					</p> -->
					<form action="addtocart.php" method="POST">
						<input value="1" type="number" name="prodqty">
						<input type="hidden" name="prodprice" value='<?php echo $result['pprice']  ?>'  >
						<input type="hidden" name="prodname" value='<?php echo $result['pname']  ?>'  >
						<input type="submit" class="prod-add" value="Add to Cart">
					</form>
					
				</div>
				<ul class="prod-i-props">
					<li>
						<b>SKU</b> 05464207
					</li>
					<li>
						<b>Material</b> Nylon
					</li>
					<li>
						<b>Pattern Type</b> Solid
					</li>
					<li>
						<b>Wash</b> Colored
					</li>
					<li>
						<b>Style</b> Sport
					</li>
					<li>
						<b>Color</b> Blue
					</li>
					<li>
						<b>Gender</b> Unisex
					</li>
					<li>
						<b>Rain Cover</b> No
					</li>
					<li>
						<b>Exterior</b> Solid Bag
					</li>
					<li><a href="#" class="prod-showprops">All Features</a></li>
				</ul>
			</div>


		</div>
		<!-- Single Product - end -->

		<!-- Related Products - start -->
		<div class="prod-related">
			<h2><span>Related products</span></h2>
			<div class="prod-related-car" id="prod-related-car">
				<ul class="slides">
				<?php

foreach($record as $row)
{ ?>
	<li class="prod-i">
	<div class="prod-i-top">
		<a href="product.php" class="prod-i-img"><!-- NO SPACE --><img src='<?php echo " ./upload/$row->pthumb" ?>' alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>
		<p class="prod-i-info">
			<a href="#" class="prod-i-favorites"><span>Wishlist</span><i class="fa fa-heart"></i></a>
			<a href="#" class="qview-btn prod-i-qview"><span>Quick View</span><i class="fa fa-search"></i></a>
			<a class="prod-i-compare" href="#"><span>Compare</span><i class="fa fa-bar-chart"></i></a>
		</p>
		<p class="prod-i-addwrap">
			<a href='product.php?id=<?php echo $row->pid; ?> ' class="prod-i-add">Go to detail</a>
		</p>
	</div>
	
	<h3>
		<a href="product.php"><?php echo $row->pname; ?></a>
	</h3>
	<p class="prod-i-price">
		<b><?php echo $row->pprice."RS"; ?></b>
	</p>
	<div class="prod-i-skuwrapcolor">
		<ul class="prod-i-skucolor">
			<li class="bx_active"><img src="img/color/red.jpg" alt="Red"></li>
			<li><img src="img/color/blue.jpg" alt="Blue"></li>
		</ul>
	</div>
</li>
<?php }
?>
					
				</ul>
			</div>
		</div>
		<!-- Related Products - end -->

	</section>
</main>
<!-- Main Content - end -->


<?php
include('./template/footer.php');
?>