<?php
session_start();

if(isset($_SESSION['loggedUser'])){
    header('Location: ./admin/index.php');
}

if(isset($_GET['fail']))
{
    echo "You have no access of dashboard";
}

include('./config.php');

$db = new Dbconnection();
$con = $db->getConnection();

$query = "select * from country";
$stmt = $con->prepare($query);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_OBJ);

if(isset($_POST['register'])){
    $custname = $_POST['custname'];
    $custemail = $_POST['custemail'];
    $custpassword = $_POST['custpassword'];
    $custdob = $_POST['custdob'];
    $custgender = $_POST['custgender'];
    $custcountryid = $_POST['custcountryid'];
    $custcardnum = $_POST['custcardnum'];
    $custemailverify = $_POST['custemailverify'];
    $custpic = $_POST['custpic'];

    
    
    $query1 = $con->prepare("insert into customer(custname,custdob,custgender,custemail,custpassword,custcardnum,custcountryid,custemailverify,custpic) values(?, ?, ? ,? ,? ,? ,? ,?,?)");
    $query1->bindParam(1, $custname);
    $query1->bindParam(2, $custdob);
    $query1->bindParam(3, $custgender);
    $query1->bindParam(4, $custemail);
    $query1->bindParam(5, $custpassword);
    $query1->bindParam(6, $custcardnum);
    $query1->bindParam(7, $custcountryid);
    $query1->bindParam(8, $custemailverify);
    $query1->bindParam(9, $custpic);
    
    $query1->execute();
}

if ( isset( $_POST[ 'login' ] ) ) {
    $custemail = $_POST[ 'custemail' ];
    $custpassword = $_POST[ 'custpassword' ];

    $query2 = $con->prepare( 'select * from customer where custemail=? && custpassword=?' );
    $query2->bindParam( 1, $custemail );
    $query2->bindParam( 2, $custpassword );
    $query2->execute();
    $count=$query2->rowCount();
 
    if($count>0){
        $_SESSION['loggeduser'] = $custemail;
        header('Location: ./admin/index.php');
    }
    else
        $msg= "invalid email or username";

}

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <title>AllStore - MultiConcept eCommerce </title>

    <link href="https://fonts.googleapis.com/css?family=PT+Serif:400,400i,700,700ii%7CRoboto:300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">


    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/ion.rangeSlider.css">
    <link rel="stylesheet" href="css/ion.rangeSlider.skinFlat.css">
    <link rel="stylesheet" href="css/jquery.bxslider.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/flexslider.css">
    <link rel="stylesheet" href="css/swiper.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/media.css">

</head>
<body>



<!-- Main Content - start -->
<main>
    <section class="container stylization maincont">


        <h1 class="main-ttl my-5"><span>Registration / Login</span></h1>
        <div class="auth-wrap">
            <div class="auth-col">
                <h2>Login</h2>
                <form method="post" class="login">
                    <p>
                        <label for="username">E-mail <span class="required">*</span></label><input type="text" name="custemail" id="username">
                    </p>
                    <p>
                        <label for="password">Password <span class="required">*</span></label><input type="password" name="custpassword" id="password">
                    </p>
                    <p class="auth-submit">
                        <input type="submit" value="Login" name="login">
                        <input type="checkbox" id="rememberme" value="forever">
                        <label for="rememberme">Remember me</label>
                    </p>
                    <p class="auth-lost_password">
                        <a href="#">Lost your password?</a>
                    </p>
                    <div class="mb-3">
                        <span class="alert-danger">
                            <?php
                                if(isset($msg))
                                {
                                    echo $msg;
                                }
                            ?>
                        </span>
                    </div>
                </form>
            </div>
            <div class="auth-col">
                <h2>Register</h2>
                <form method="post" class="register">
                    <p>
                        <label for="reg_email">Name <span class="required">*</span></label><input type="text" name="custname" id="reg_email">
                    </p>
                    
                    <p>
                        <label for="reg_email">Email <span class="required">*</span></label><input type="email" name="custemail" id="reg_email">
                    </p>
                    <p>
                        <label for="reg_password">Password <span class="required">*</span></label><input type="password" name="custpassword" id="reg_password">
                    </p>
                    
                    <p>
                        <label for="reg_email">Verify Email <span class="required">*</span></label><input type="email" name="custemailverify" id="reg_email">
                    </p>
                    <p>
                        <label for="reg_password">cardnum <span class="required">*</span></label><input type="text" name="custcardnum" id="reg_password">
                    </p>
                    <p>
                        <label for="reg_email">Date of birth <span class="required">*</span></label><input type="date" name="custdob" id="reg_email">
                    </p>    
                    <p>
                    
                    <label for="" class="form-label">Gender</label>
                    <input type="radio" name="custgender" value="1">Male
                    <input type="radio" name="custgender" value="0">Female
                    
                </p>
                    

                    <p>
                        <input type="file" class="form-control" name="custpic">
                    
                    </p>

                    <select name="custcountryid" id="">
                        <?php
                        foreach($result as $row){
                            echo "<option value = '$row->countryid'>$row->countryname </option> ";
                        }
                        
                        ?>
                    </select>

                    <p class="auth-submit">
                        <input type="submit" name="register" value="Register">
                    </p>
                  
                </form>
            </div>
        </div>



    </section>
</main>
<!-- Main Content - end -->




<!-- jQuery plugins/scripts - start -->
<script src="js/jquery-1.11.2.min.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/fancybox/fancybox.js"></script>
<script src="js/fancybox/helpers/jquery.fancybox-thumbs.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/swiper.jquery.min.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/progressbar.min.js"></script>
<script src="js/ion.rangeSlider.min.js"></script>
<script src="js/chosen.jquery.min.js"></script>
<script src="js/jQuery.Brazzers-Carousel.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDhAYvx0GmLyN5hlf6Uv_e9pPvUT3YpozE"></script>
<script src="js/gmap.js"></script>
<!-- jQuery plugins/scripts - end -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
</body>
</html>